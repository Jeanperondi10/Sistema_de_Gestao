public class Diretor extends Gerente {
	String departamento;
	double valorLucro;
}
