import java.util.*;
public class programa {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		
		//ESCOPO DE VARIAVEIS UNIVERSAIS
			
			/*Escolha dos menus
			    op1=Situacao(cadastro, consulta, alteracao)
			    op2=Tipo de funcionario(comum, gerente, diretor)
			*/
			int op1,op2,op,i;
			String nome="";//grava o nome escolhido
			
			//Lista que armazena as variaveis unicas preenchidas em cadastro 
			ArrayList<Comum> listComum = new ArrayList();
			ArrayList<Gerente> listGerente = new ArrayList();
			ArrayList<Diretor> listDiretor = new ArrayList();
			
			//Variaveis unicas que serao preenchidas no cadastro
			Comum comum=new Comum();
			Gerente gerente=new Gerente();
			Diretor diretor=new Diretor();
		do{
			esp();
			p("----MONITOR EMPRESARIAL---\n|                        |\n|                        |\n|  1-Geren. funcionarios |\n|  2-Relatorio financeiro|\n|  3-Sobre               |\n|  0-Sair                |\n--------------------------\n>");
			op=input.nextInt();
			//Seleciona uma opicao entre gerenciar ou apresentar relatorio dos funcionarios
			switch(op){
				//GERENCIAMENTO DE FUNCIONARIOS
				case 1:
					do {
						esp();
						p("----MONITOR EMPRESARIAL---\n|                        |\n|  Geren. funcionarios   |\n|      1-Cadastrar       |\n|      2-Consultar       |\n|      3-Alterar         |\n|      0-Voltar          |\n--------------------------\n>");
						op1=input.nextInt();
						if(op1==1||op1==2||op1==3){
							do {
								esp();
								p("----MONITOR EMPRESARIAL---\n|                        |\n|   Selecione o tipo:    |\n|       1-Comum          |\n|       2-Gerente        |\n|       3-Diretor        |\n|       0-Voltar         |\n--------------------------\n>");
								op2=input.nextInt();
							}while(op2!=0&&op2!=1&&op2!=2&&op2!=3);
							
							//Chekar a situacao
							switch (op1) {
								
								//CADASTRACAO
								case 1:
									switch (op2) {
										//Funcionario comum
										case 1:
											nome="comum";
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|      Cadastramento     |\n|  Nome:");
											input.nextLine();
											comum.nome=input.nextLine();
											p("|  Data de Nasc.:");
											comum.dataNascimento=input.nextLine();
											p("|  Data Ingresso:");
											comum.dataIngresso=input.nextLine();
											p("|  Nome do Banco:");
											comum.nomeBanco=input.nextLine();
											p("|  Num.  Agencia:");
											comum.agencia=input.nextInt();
											p("|  Conta corente:");
											input.nextLine();
											comum.contaCorrente=input.nextLine();
											p("|  Banco n Horas:");
											comum.bancoHoras=input.nextInt();
											p("|  Salario:");
											comum.salario=input.nextDouble();
											
											//Adiciona na lista de comuns
											listComum.add(comum);
											
											break;
										//Funcionario gerente
										case 2:
											nome="gerente";
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|      Cadastramento     |\n|  Nome:");
											input.nextLine();
											gerente.nome=input.nextLine();
											p("|  Data de Nasc.:");
											gerente.dataNascimento=input.nextLine();
											p("|  Data Ingresso:");
											gerente.dataIngresso=input.nextLine();
											p("|  Nome do Banco:");
											gerente.nomeBanco=input.nextLine();
											p("|  Num.  Agencia:");
											gerente.agencia=input.nextInt();
											p("|  Conta corente:");
											input.nextLine();
											gerente.contaCorrente=input.nextLine();
											p("|  Banco n Horas:");
											gerente.bancoHoras=input.nextInt();
											p("|  Salario:");
											gerente.salario=input.nextDouble();
											p("|  Setor:");
											input.nextLine();
											gerente.setor=input.nextLine();
											p("|  Nivel:");
											gerente.nivel=input.nextLine();
											
											//Adiciona na lista de gerentes
											listGerente.add(gerente);
											
											break;
										//Funcionario Diretor
										case 3:
											nome="diretor";
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|      Cadastramento     |\n|  Nome:");
											input.nextLine();
											diretor.nome=input.nextLine();
											p("|  Data de Nasc.:");
											diretor.dataNascimento=input.nextLine();
											p("|  Data Ingresso:");
											diretor.dataIngresso=input.nextLine();
											p("|  Nome do Banco:");
											diretor.nomeBanco=input.nextLine();
											p("|  Num.  Agencia:");
											diretor.agencia=input.nextInt();
											p("|  Conta corente:");
											input.nextLine();
											diretor.contaCorrente=input.nextLine();
											p("|  Banco n Horas:");
											diretor.bancoHoras=input.nextInt();
											p("|  Salario:");
											diretor.salario=input.nextDouble();
											p("|  Setor:");
											input.nextLine();
											diretor.setor=input.nextLine();
											p("|  Nivel:");
											diretor.nivel=input.nextLine();
											p("|  Departamento:");
											diretor.departamento=input.nextLine();
											p("|  Valor do Lucro:");
											diretor.valorLucro=input.nextInt();
											
											//Adiciona na lista de Diretores
											listDiretor.add(diretor);
											break;
									}
									p("--------------------------\nFuncionario "+nome+"\nCadastrado com sucesso!\n");
									input.nextLine(); input.nextLine();
									break;
								
								//CONSULTACAO
								case 2:
									//Qual o tipo de Funcionario
									switch (op2) {
										//Funcionario comum
										case 1:
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|        Consulta        |\n|    Digite a posicao:   |\n|>");														// |      Cadastramento     |  |        Consulta        |
											i=input.nextInt();
											if(i<listComum.size()&&i>=0){
												p("\n|  DADOS DO FUNCIONARIO Nº"+i);
												p("\n|  Nome:"+listComum.get(i).nome);
												p("\n|  Data de Nasc.:"+listComum.get(i).dataNascimento);
												p("\n|  Data Ingresso:"+listComum.get(i).dataIngresso);
												p("\n|  Nome do Banco:"+listComum.get(i).nomeBanco);
												p("\n|  Num.  Agencia:"+listComum.get(i).agencia);
												p("\n|  Conta corente:"+listComum.get(i).contaCorrente);
												p("\n|  Banco n Horas:"+listComum.get(i).bancoHoras);
												p("\n|  Salario:"+listComum.get(i).salario);
												p("\n--------------------------\nDigite um valor para continuar");
												input.nextLine(); input.nextLine();
											}else{
												p("ERRO! posicao inexistente");
												input.nextLine(); input.nextLine();
											}
											break;
											
										//Funcionario gerente
										case 2:
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|        Consulta        |\n|    Digite a posicao:   |");														// |      Cadastramento     |  |        Consulta        |
											i=input.nextInt();
											if(i<listGerente.size()&&i>=0){
												p("|  DADOS DO FUNCIONARIO Nº"+i);
												p("\n|  Nome:"+listGerente.get(i).nome);
												p("\n|  Data de Nasc.:"+listGerente.get(i).dataNascimento);
												p("\n|  Data Ingresso:"+listGerente.get(i).dataIngresso);
												p("\n|  Nome do Banco:"+listGerente.get(i).nomeBanco);
												p("\n|  Num.  Agencia:"+listGerente.get(i).agencia);
												p("\n|  Conta corente:"+listGerente.get(i).contaCorrente);
												p("\n|  Banco n Horas:"+listGerente.get(i).bancoHoras);
												p("\n|  Salario:"+listGerente.get(i).salario);
												p("\n|  Setor:"+listGerente.get(i).setor);
												p("\n|  Nivel:"+listGerente.get(i).nivel);
												p("--------------------------\nDigite um valor para continuar");
												input.nextLine(); input.nextLine();
											}else{
												p("ERRO! posicao inexistente");
												input.nextLine(); input.nextLine();
											}
											break;
										case 3:
											esp();
											p("----MONITOR EMPRESARIAL---\n|                        |\n|        Consulta        |\n|    Digite a posicao:   |");														// |      Cadastramento     |  |        Consulta        |
											i=input.nextInt();
											if(i<listDiretor.size()&&i>=0){
												p("\n|  DADOS DO FUNCIONARIO Nº"+i);
												p("\n|  Nome:"+listDiretor.get(i).nome);
												p("\n|  Data de Nasc.:"+listDiretor.get(i).dataNascimento);
												p("\n|  Data Ingresso:"+listDiretor.get(i).dataIngresso);
												p("\n|  Nome do Banco:"+listDiretor.get(i).nomeBanco);
												p("\n|  Num.  Agencia:"+listDiretor.get(i).agencia);
												p("\n|  Conta corente:"+listDiretor.get(i).contaCorrente);
												p("\n|  Banco n Horas:"+listDiretor.get(i).bancoHoras);
												p("\n|  Salario:"+listDiretor.get(i).salario);
												p("\n|  Setor:"+listDiretor.get(i).setor);
												p("\n|  Nivel:"+listDiretor.get(i).nivel);
												p("\n|  Departamento:"+listDiretor.get(i).departamento);
												p("\n|  Valor do Lucro:"+listDiretor.get(i).valorLucro);
												p("--------------------------\nDigite um valor para continuar");
												input.nextLine(); input.nextLine();
											}else{
												p("ERRO! posicao inexistente");
												input.nextLine(); input.nextLine();
											}
											break;
										default:
											break;
									}
									break;
								//ALTERACAO
								case 3:
									//Qual o tipo de Funcionario
									switch (op2) {
										case 1:
											break;
										case 2:
											break;
										case 3:
											break;
										default:
											break;
									}
									break;
								default:
									break;
							}
						}		
					}while(op1!=0);
					break;
					
				//RELATORIOS DOS FUNCIONARIOS
				case 2:
					break;
				
				//MENU SOBRE
				case 3:
					break;
					
				//FENALIZACAO DO PROGRAMA
				case 0:
					p("Programa finalizado!");
					break;
				default:
					break;
			}
		}while(op!=0);
	}
	
	//FUNCOES-----------------------------------------
	//Quebra linha varias vezes deixando espaço no superior
		public static void esp() {
			for(int x=0;x<10;x++) {
				System.out.print("\n\n\n\n\n");
			}
		}
	//Simplificacao do "System.out.print()" para "p()"
		public static void p(String t) {
			System.out.print(t);
		}
}
