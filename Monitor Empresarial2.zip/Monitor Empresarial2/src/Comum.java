public class Comum {
	String nome;
	String dataNascimento;
	String dataIngresso;
	String nomeBanco;
	int agencia;
	String contaCorrente;
	int bancoHoras;
	double salario; 
}
