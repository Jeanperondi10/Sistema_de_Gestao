public class Gerente extends Comum {
	String setor;
	String nivel;
}
